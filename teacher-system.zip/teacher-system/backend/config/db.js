const mysql = require('mysql2/promise');
require('dotenv').config();

let pool = null;

async function getConnection() {
    try {
        if (pool) {
            return pool;
        }
        pool = mysql.createPool({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT || 3306,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0,
            charset: 'utf8mb4'
        });
        console.log('✅ MySQL 连接池创建成功');
        return pool;
    } catch (err) {
        console.error('❌ 数据库连接失败:', err.message);
        throw err;
    }
}

async function closeConnection() {
    if (pool) {
        await pool.end();
        pool = null;
        console.log('数据库连接池已关闭');
    }
}

// 导出 sql 对象（保留兼容性，实际使用 execute）
module.exports = { getConnection, closeConnection, sql: mysql };