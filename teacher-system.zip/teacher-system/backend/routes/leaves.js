const express = require('express');
const { getConnection, sql } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// 获取所有请假记录
router.get('/', authenticate, async (req, res) => {
    try {
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT l.*, t.name AS teacher_name, d.dept_name
            FROM Leaves l
            LEFT JOIN Teachers t ON l.teacher_id = t.teacher_id
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            ORDER BY l.created_at DESC
        `);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取请假记录失败' });
    }
});

// 获取教师个人请假记录
router.get('/teacher/:teacher_id', authenticate, async (req, res) => {
    try {
        const { teacher_id } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.execute(`
            SELECT l.*, t.name AS teacher_name
            FROM Leaves l
            LEFT JOIN Teachers t ON l.teacher_id = t.teacher_id
            WHERE l.teacher_id = ?
            ORDER BY l.created_at DESC
        `, [teacher_id]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取教师请假记录失败' });
    }
});

// 提交请假申请
router.post('/', authenticate, async (req, res) => {
    try {
        const { leave_id, teacher_id, leave_type, start_date, end_date, reason } = req.body;
        if (!leave_id || !teacher_id || !leave_type || !start_date || !end_date || !reason) {
            return res.status(400).json({ error: '所有必填字段不能为空' });
        }

        const pool = await getConnection();
        const [existRows] = await pool.execute('SELECT leave_id FROM Leaves WHERE leave_id = ?', [leave_id]);
        if (existRows.length > 0) {
            return res.status(400).json({ error: '请假编号已存在' });
        }

        await pool.execute(`
            INSERT INTO Leaves (leave_id, teacher_id, leave_type, start_date, end_date, reason, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, '待审核', NOW())
        `, [leave_id, teacher_id, leave_type, start_date, end_date, reason]);

        res.status(201).json({ message: '请假申请提交成功', leave_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '提交请假申请失败' });
    }
});

// 审核请假（通过/驳回）
router.put('/:leave_id/approve', authenticate, requireRole('超级管理员', '教务员'), async (req, res) => {
    try {
        const { leave_id } = req.params;
        const { status, approver } = req.body;
        if (!status || !['已通过', '已驳回'].includes(status)) {
            return res.status(400).json({ error: '审批状态必须为"已通过"或"已驳回"' });
        }

        const pool = await getConnection();
        
        // 获取请假详情
        const [leaveRows] = await pool.execute(
            'SELECT teacher_id, start_date, end_date, status FROM Leaves WHERE leave_id = ?',
            [leave_id]
        );
        if (leaveRows.length === 0) {
            return res.status(404).json({ error: '请假记录不存在' });
        }
        const leave = leaveRows[0];
        if (leave.status !== '待审核') {
            return res.status(400).json({ error: '该请假已审核，不能重复操作' });
        }

        // 更新请假状态
        await pool.execute(`
            UPDATE Leaves SET
                status = ?,
                approver = ?,
                approve_time = NOW()
            WHERE leave_id = ?
        `, [status, approver || '系统管理员', leave_id]);

        // 如果审批通过，更新考勤状态为“请假”
        if (status === '已通过') {
            await pool.execute(`
                UPDATE Attendance
                SET status = '请假',
                    remark = CONCAT(IFNULL(remark, ''), ' 请假审批通过')
                WHERE teacher_id = ? AND check_date BETWEEN ? AND ?
            `, [leave.teacher_id, leave.start_date, leave.end_date]);
        }

        res.json({ message: '请假审核完成', leave_id, status });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '审核请假失败' });
    }
});

// 删除请假记录
router.delete('/:leave_id', authenticate, requireRole('超级管理员'), async (req, res) => {
    try {
        const { leave_id } = req.params;
        const pool = await getConnection();
        const [result] = await pool.execute('DELETE FROM Leaves WHERE leave_id = ?', [leave_id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: '请假记录不存在' });
        }
        res.json({ message: '请假记录删除成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '删除请假记录失败' });
    }
});

module.exports = router;