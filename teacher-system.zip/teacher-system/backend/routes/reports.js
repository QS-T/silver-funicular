const express = require('express');
const { getConnection, sql } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// 月度课时统计（直接查询）
router.get('/monthly/:year/:month', authenticate, async (req, res) => {
    try {
        const { year, month } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT 
                t.teacher_id,
                t.name,
                d.dept_name,
                COUNT(a.record_id) AS work_days,
                SUM(CASE WHEN a.status = '正常' THEN 1 ELSE 0 END) AS normal_days,
                SUM(CASE WHEN a.status = '迟到' THEN 1 ELSE 0 END) AS late_days,
                SUM(CASE WHEN a.status = '早退' THEN 1 ELSE 0 END) AS early_days,
                SUM(CASE WHEN a.status = '旷工' THEN 1 ELSE 0 END) AS absent_days,
                SUM(CASE WHEN a.status = '请假' THEN 1 ELSE 0 END) AS leave_days,
                SUM(a.actual_hours) AS total_hours
            FROM Teachers t
            LEFT JOIN Attendance a ON t.teacher_id = a.teacher_id 
                AND YEAR(a.check_date) = ? AND MONTH(a.check_date) = ?
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            WHERE t.is_active = 1
            GROUP BY t.teacher_id, t.name, d.dept_name
            ORDER BY d.dept_name, t.name
        `, [year, month]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取月度统计失败' });
    }
});

// 部门考勤报表（直接查询）
router.get('/department/:dept_id/:year/:month', authenticate, requireRole('超级管理员', '教务员', '校领导'), async (req, res) => {
    try {
        const { dept_id, year, month } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT 
                t.teacher_id,
                t.name,
                t.position,
                COUNT(a.record_id) AS check_days,
                SUM(CASE WHEN a.status = '正常' THEN 1 ELSE 0 END) AS normal_count,
                SUM(CASE WHEN a.status = '迟到' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN a.status = '早退' THEN 1 ELSE 0 END) AS early_count,
                SUM(CASE WHEN a.status = '旷工' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN a.status = '请假' THEN 1 ELSE 0 END) AS leave_count,
                SUM(a.actual_hours) AS total_teaching_hours,
                t.standard_hours,
                (SUM(a.actual_hours) - t.standard_hours) AS hours_diff
            FROM Teachers t
            LEFT JOIN Attendance a ON t.teacher_id = a.teacher_id 
                AND YEAR(a.check_date) = ? AND MONTH(a.check_date) = ?
            WHERE t.dept_id = ? AND t.is_active = 1
            GROUP BY t.teacher_id, t.name, t.position, t.standard_hours
            ORDER BY t.name
        `, [year, month, dept_id]);
        res.json(rows);
    } catch (err) {
        console.error('部门报表错误:', err);
        res.status(500).json({ error: '获取部门报表失败: ' + err.message });
    }
});

// 教师个人月度汇总（直接查询）
router.get('/teacher/:teacher_id/:year/:month', authenticate, async (req, res) => {
    try {
        const { teacher_id, year, month } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT 
                t.teacher_id,
                t.name,
                t.position,
                d.dept_name,
                COUNT(a.record_id) AS work_days,
                SUM(CASE WHEN a.status = '正常' THEN 1 ELSE 0 END) AS normal_days,
                SUM(CASE WHEN a.status = '迟到' THEN 1 ELSE 0 END) AS late_days,
                SUM(CASE WHEN a.status = '早退' THEN 1 ELSE 0 END) AS early_days,
                SUM(CASE WHEN a.status = '旷工' THEN 1 ELSE 0 END) AS absent_days,
                SUM(CASE WHEN a.status = '请假' THEN 1 ELSE 0 END) AS leave_days,
                SUM(a.actual_hours) AS total_hours,
                t.standard_hours,
                (SUM(a.actual_hours) - t.standard_hours) AS hours_diff
            FROM Teachers t
            LEFT JOIN Attendance a ON t.teacher_id = a.teacher_id 
                AND YEAR(a.check_date) = ? AND MONTH(a.check_date) = ?
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            WHERE t.teacher_id = ?
            GROUP BY t.teacher_id, t.name, t.position, d.dept_name, t.standard_hours
        `, [year, month, teacher_id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: '教师不存在或没有考勤数据' });
        }
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取教师月度汇总失败' });
    }
});

// 全校考勤汇总（领导端）
router.get('/summary/:year/:month', authenticate, requireRole('超级管理员', '校领导'), async (req, res) => {
    try {
        const { year, month } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT 
                d.dept_name,
                COUNT(DISTINCT t.teacher_id) AS teacher_count,
                COUNT(a.record_id) AS total_check_days,
                SUM(CASE WHEN a.status = '正常' THEN 1 ELSE 0 END) AS normal_count,
                SUM(CASE WHEN a.status = '迟到' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN a.status = '早退' THEN 1 ELSE 0 END) AS early_count,
                SUM(CASE WHEN a.status = '旷工' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN a.status = '请假' THEN 1 ELSE 0 END) AS leave_count,
                SUM(a.actual_hours) AS total_hours
            FROM Departments d
            LEFT JOIN Teachers t ON d.dept_id = t.dept_id AND t.is_active = 1
            LEFT JOIN Attendance a ON t.teacher_id = a.teacher_id 
                AND YEAR(a.check_date) = ? AND MONTH(a.check_date) = ?
            GROUP BY d.dept_id, d.dept_name
            ORDER BY d.dept_name
        `, [year, month]);

        // 计算总计（强制数字转换）
        const total = {
            dept_name: '全校总计',
            teacher_count: rows.reduce((s, r) => s + Number(r.teacher_count || 0), 0),
            total_check_days: rows.reduce((s, r) => s + Number(r.total_check_days || 0), 0),
            normal_count: rows.reduce((s, r) => s + Number(r.normal_count || 0), 0),
            late_count: rows.reduce((s, r) => s + Number(r.late_count || 0), 0),
            early_count: rows.reduce((s, r) => s + Number(r.early_count || 0), 0),
            absent_count: rows.reduce((s, r) => s + Number(r.absent_count || 0), 0),
            leave_count: rows.reduce((s, r) => s + Number(r.leave_count || 0), 0),
            total_hours: rows.reduce((s, r) => s + Number(r.total_hours || 0), 0)
        };

        res.json({
            departments: rows,
            total
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取全校汇总失败' });
    }
});

// 缺勤教师筛选
router.get('/absent/:year/:month', authenticate, requireRole('超级管理员', '教务员', '校领导'), async (req, res) => {
    try {
        const { year, month } = req.params;
        const { threshold = 2 } = req.query;
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT 
                t.teacher_id,
                t.name,
                d.dept_name,
                COUNT(a.record_id) AS total_days,
                SUM(CASE WHEN a.status IN ('旷工', '迟到', '早退') THEN 1 ELSE 0 END) AS absent_days,
                SUM(CASE WHEN a.status = '旷工' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN a.status = '迟到' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN a.status = '早退' THEN 1 ELSE 0 END) AS early_count
            FROM Teachers t
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            LEFT JOIN Attendance a ON t.teacher_id = a.teacher_id 
                AND YEAR(a.check_date) = ? AND MONTH(a.check_date) = ?
            WHERE t.is_active = 1
            GROUP BY t.teacher_id, t.name, d.dept_name
            HAVING SUM(CASE WHEN a.status IN ('旷工', '迟到', '早退') THEN 1 ELSE 0 END) >= ?
            ORDER BY absent_days DESC
        `, [year, month, threshold]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取缺勤教师列表失败' });
    }
});

module.exports = router;