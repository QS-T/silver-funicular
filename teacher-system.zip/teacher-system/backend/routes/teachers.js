const express = require('express');
const { getConnection, sql } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// 获取所有教师（带部门信息）
router.get('/', authenticate, async (req, res) => {
    try {
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT t.*, d.dept_name 
            FROM Teachers t
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            WHERE t.is_active = 1
            ORDER BY t.teacher_id
        `);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取教师列表失败' });
    }
});

// 获取单个教师
router.get('/:id', authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getConnection();
        const [rows] = await pool.execute(`
            SELECT t.*, d.dept_name 
            FROM Teachers t
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            WHERE t.teacher_id = ?
        `, [id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: '教师不存在' });
        }
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取教师信息失败' });
    }
});

// 新增教师（支持复职）
router.post('/', authenticate, requireRole('超级管理员', '教务员'), async (req, res) => {
    try {
        const { teacher_id, name, gender, hire_date, position, standard_hours, phone, dept_id } = req.body;
        if (!teacher_id || !name || !gender || !hire_date || !position || !phone || !dept_id) {
            return res.status(400).json({ error: '所有必填字段不能为空' });
        }

        const pool = await getConnection();
        
        // 检查工号是否存在
        const [existRows] = await pool.execute(
            'SELECT teacher_id, is_active FROM Teachers WHERE teacher_id = ?',
            [teacher_id]
        );
        
        // 检查手机号是否被其他在职教师占用
        const [phoneRows] = await pool.execute(
            'SELECT teacher_id FROM Teachers WHERE phone = ? AND teacher_id != ? AND is_active = 1',
            [phone, teacher_id]
        );
        if (phoneRows.length > 0) {
            return res.status(400).json({ error: '手机号已被其他在职教师使用' });
        }
        
        if (existRows.length > 0) {
            // 工号已存在 → 复职（更新）
            await pool.execute(`
                UPDATE Teachers SET
                    name = ?,
                    gender = ?,
                    hire_date = ?,
                    position = ?,
                    standard_hours = ?,
                    phone = ?,
                    dept_id = ?,
                    is_active = 1
                WHERE teacher_id = ?
            `, [name, gender, hire_date, position, standard_hours || 140, phone, dept_id, teacher_id]);
            res.json({ message: '教师信息已更新（复职成功）', teacher_id });
        } else {
            // 工号不存在 → 新增
            await pool.execute(`
                INSERT INTO Teachers 
                (teacher_id, name, gender, hire_date, position, standard_hours, phone, dept_id, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            `, [teacher_id, name, gender, hire_date, position, standard_hours || 140, phone, dept_id]);
            res.status(201).json({ message: '教师添加成功', teacher_id });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '处理教师信息失败' });
    }
});

// 更新教师信息
router.put('/:id', authenticate, requireRole('超级管理员', '教务员'), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, gender, hire_date, position, standard_hours, phone, dept_id, is_active } = req.body;

        const pool = await getConnection();
        const [existRows] = await pool.execute('SELECT teacher_id FROM Teachers WHERE teacher_id = ?', [id]);
        if (existRows.length === 0) {
            return res.status(404).json({ error: '教师不存在' });
        }

        await pool.execute(`
            UPDATE Teachers SET
                name = ?,
                gender = ?,
                hire_date = ?,
                position = ?,
                standard_hours = ?,
                phone = ?,
                dept_id = ?,
                is_active = ?
            WHERE teacher_id = ?
        `, [name, gender, hire_date, position, standard_hours, phone, dept_id, is_active !== undefined ? is_active : 1, id]);

        res.json({ message: '教师信息更新成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '更新教师信息失败' });
    }
});

// 删除教师（软删除）
router.delete('/:id', authenticate, requireRole('超级管理员'), async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await getConnection();
        const [existRows] = await pool.execute(
            'SELECT teacher_id FROM Teachers WHERE teacher_id = ? AND is_active = 1',
            [id]
        );
        if (existRows.length === 0) {
            return res.status(404).json({ error: '教师不存在或已删除' });
        }

        await pool.execute('UPDATE Teachers SET is_active = 0 WHERE teacher_id = ?', [id]);
        res.json({ message: '教师已离职（软删除）' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '删除教师失败' });
    }
});

module.exports = router;