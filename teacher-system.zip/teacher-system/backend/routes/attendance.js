const express = require('express');
const { getConnection, sql } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');

const router = express.Router();

// 清洗时间参数
function sanitizeTime(value) {
    if (typeof value !== 'string') {
        return null;
    }
    const trimmed = value.trim();
    if (trimmed === '') {
        return null;
    }
    if (!/^\d{2}:\d{2}(:\d{2})?$/.test(trimmed)) {
        return null;
    }
    return trimmed;
}

// 计算考勤状态
function calculateStatus(checkIn, checkOut) {
    let status = '';
    if (checkIn) {
        if (checkIn > '08:00:00') {
            status = '迟到';
        } else {
            status = '正常';
        }
    }
    if (checkOut) {
        if (checkOut < '17:00:00') {
            if (status) {
                status = status + '+早退';
            } else {
                status = '早退';
            }
        }
    }
    if (!checkIn && checkOut) {
        status = '缺卡';  // 只打了下班卡
    }
    if (!checkOut && checkIn) {
        // 只有上班卡，状态已设定
    }
    if (!checkIn && !checkOut) {
        status = '未打卡';
    }
    return status;
}

// 获取所有考勤记录（保持不变）
router.get('/', authenticate, async (req, res) => {
    try {
        const pool = await getConnection();
        const [rows] = await pool.query(`
            SELECT a.*, t.name AS teacher_name, d.dept_name
            FROM Attendance a
            LEFT JOIN Teachers t ON a.teacher_id = t.teacher_id
            LEFT JOIN Departments d ON t.dept_id = d.dept_id
            ORDER BY a.check_date DESC, a.record_id
        `);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取考勤记录失败' });
    }
});

// 获取教师个人考勤
router.get('/teacher/:teacher_id', authenticate, async (req, res) => {
    try {
        const { teacher_id } = req.params;
        const { start_date, end_date } = req.query;
        const pool = await getConnection();
        let sql = `
            SELECT a.*, t.name AS teacher_name
            FROM Attendance a
            LEFT JOIN Teachers t ON a.teacher_id = t.teacher_id
            WHERE a.teacher_id = ?
        `;
        const params = [teacher_id];
        if (start_date) {
            sql += ' AND a.check_date >= ?';
            params.push(start_date);
        }
        if (end_date) {
            sql += ' AND a.check_date <= ?';
            params.push(end_date);
        }
        sql += ' ORDER BY a.check_date DESC';
        const [rows] = await pool.execute(sql, params);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '获取教师考勤失败' });
    }
});

// 打卡（上班/下班） - 核心修改
router.post('/clock', authenticate, async (req, res) => {
    try {
        const teacher_id = req.body.teacher_id ? req.body.teacher_id.trim() : null;
        const check_date = req.body.check_date;
        const checkIn = sanitizeTime(req.body.check_in);
        const checkOut = sanitizeTime(req.body.check_out);
        const remark = req.body.remark ? req.body.remark.trim() : null;

        if (req.body.check_in && checkIn === null) {
            return res.status(400).json({ error: '上班时间格式无效，请使用 HH:mm 或 HH:mm:ss' });
        }
        if (req.body.check_out && checkOut === null) {
            return res.status(400).json({ error: '下班时间格式无效，请使用 HH:mm 或 HH:mm:ss' });
        }
        if (!teacher_id || !check_date) {
            return res.status(400).json({ error: '教师ID和日期不能为空' });
        }
        if (!checkIn && !checkOut) {
            return res.status(400).json({ error: '请提供上班或下班打卡时间' });
        }

        const pool = await getConnection();

        // 检查是否已有记录
        const [existRows] = await pool.execute(
            'SELECT record_id, check_in, check_out FROM Attendance WHERE teacher_id = ? AND check_date = ?',
            [teacher_id, check_date]
        );

        let record_id;
        let status = '';
        if (existRows.length > 0) {
            // 更新已有记录
            const existing = existRows[0];
            const updateIn = checkIn || existing.check_in;
            const updateOut = checkOut || existing.check_out;

            if (!updateIn && !updateOut) {
                return res.status(400).json({ error: '请提供上班或下班打卡时间' });
            }

            // 计算新状态（基于更新后的时间）
            status = calculateStatus(updateIn, updateOut);

            await pool.execute(`
                UPDATE Attendance SET
                    check_in = COALESCE(?, check_in),
                    check_out = COALESCE(?, check_out),
                    status = ?,
                    remark = COALESCE(?, remark)
                WHERE record_id = ?
            `, [updateIn, updateOut, status, remark, existing.record_id]);
            record_id = existing.record_id;
        } else {
            // 新增记录
            // 计算状态
            status = calculateStatus(checkIn, checkOut);

            // 生成 record_id
            const [idRows] = await pool.query(
                "SELECT CONCAT('K', LPAD(IFNULL(MAX(CAST(SUBSTRING(record_id, 2) AS UNSIGNED)), 0) + 1, 3, '0')) AS new_id FROM Attendance"
            );
            record_id = idRows[0].new_id || 'K001';

            await pool.execute(`
                INSERT INTO Attendance (record_id, teacher_id, check_date, check_in, check_out, status, remark)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `, [record_id, teacher_id, check_date, checkIn, checkOut, status, remark]);
        }

        const [resultRows] = await pool.execute('SELECT * FROM Attendance WHERE record_id = ?', [record_id]);
        res.json({ message: '打卡成功', record: resultRows[0] });
    } catch (err) {
        console.error('打卡详细错误:', err);
        res.status(500).json({ error: '打卡失败: ' + err.message });
    }
});

// 修改考勤记录（保持不变）
router.put('/:record_id', authenticate, requireRole('超级管理员', '教务员'), async (req, res) => {
    try {
        const { record_id } = req.params;
        const { check_in, check_out, status, remark } = req.body;
        const pool = await getConnection();
        const [existRows] = await pool.execute('SELECT record_id FROM Attendance WHERE record_id = ?', [record_id]);
        if (existRows.length === 0) {
            return res.status(404).json({ error: '考勤记录不存在' });
        }
        await pool.execute(`
            UPDATE Attendance SET
                check_in = COALESCE(?, check_in),
                check_out = COALESCE(?, check_out),
                status = COALESCE(?, status),
                remark = COALESCE(?, remark)
            WHERE record_id = ?
        `, [check_in, check_out, status, remark, record_id]);
        res.json({ message: '考勤记录更新成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '更新考勤记录失败' });
    }
});

// 删除考勤记录（保持不变）
router.delete('/:record_id', authenticate, requireRole('超级管理员'), async (req, res) => {
    try {
        const { record_id } = req.params;
        const pool = await getConnection();
        const [result] = await pool.execute('DELETE FROM Attendance WHERE record_id = ?', [record_id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: '考勤记录不存在' });
        }
        res.json({ message: '考勤记录删除成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '删除考勤记录失败' });
    }
});

module.exports = router;