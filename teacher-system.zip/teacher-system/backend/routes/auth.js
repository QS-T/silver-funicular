const express = require('express');
const { getConnection, sql } = require('../config/db');
const { generateToken, authenticate } = require('../middleware/auth');

const router = express.Router();

// 统一登录接口
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).json({ error: '用户名和密码不能为空' });
        }

        const pool = await getConnection();
        let [rows] = await pool.execute(
            'SELECT * FROM Admins WHERE username = ?',
            [username]
        );
        let userInfo = null;

        if (rows.length > 0) {
            const admin = rows[0];
            if (admin.password_hash !== password) {
                return res.status(401).json({ error: '用户名或密码错误' });
            }
            userInfo = {
                admin_id: admin.admin_id,
                username: admin.username,
                role: admin.role,
                permissions: admin.permissions
            };
        } else {
            [rows] = await pool.execute(
                'SELECT teacher_id, name, password_hash, is_active FROM Teachers WHERE teacher_id = ?',
                [username]
            );
            if (rows.length === 0) {
                return res.status(401).json({ error: '用户名或密码错误' });
            }
            const teacher = rows[0];
            if (teacher.is_active !== 1) {
                return res.status(401).json({ error: '账号已停用，请联系管理员' });
            }
            if (teacher.password_hash !== password) {
                return res.status(401).json({ error: '用户名或密码错误' });
            }
            userInfo = {
                teacher_id: teacher.teacher_id,
                username: teacher.teacher_id,  // 用工号作为 username
                name: teacher.name,
                role: '教师'
            };
        }

        const token = generateToken(userInfo);
        res.json({ token, user: userInfo });
    } catch (err) {
        console.error('登录错误:', err);
        res.status(500).json({ error: '登录失败' });
    }
});

// 验证令牌
router.get('/verify', authenticate, async (req, res) => {
    try {
        res.json({ valid: true, user: req.user });
    } catch (err) {
        res.status(401).json({ valid: false, error: err.message });
    }
});

// 修改密码
router.post('/change-password', authenticate, async (req, res) => {
    try {
        const { oldPassword, newPassword } = req.body;
        if (!oldPassword || !newPassword) {
            return res.status(400).json({ error: '旧密码和新密码不能为空' });
        }
        if (newPassword.length < 6) {
            return res.status(400).json({ error: '新密码长度至少6位' });
        }

        const user = req.user;
        const pool = await getConnection();

        let tableName, idField, idValue;
        if (user.role === '教师') {
            // 优先使用 teacher_id，如果没有则使用 username（工号）
            idValue = user.teacher_id || user.username;
            if (!idValue) {
                return res.status(400).json({ error: '教师信息不完整，请重新登录' });
            }
            tableName = 'Teachers';
            idField = 'teacher_id';
        } else {
            if (!user.admin_id) {
                return res.status(400).json({ error: '管理员信息不完整，请重新登录' });
            }
            tableName = 'Admins';
            idField = 'admin_id';
            idValue = user.admin_id;
        }

        // 验证旧密码
        const [rows] = await pool.execute(
            `SELECT password_hash FROM ${tableName} WHERE ${idField} = ?`,
            [idValue]
        );
        if (rows.length === 0) {
            return res.status(404).json({ error: '用户不存在' });
        }
        if (rows[0].password_hash !== oldPassword) {
            return res.status(401).json({ error: '旧密码错误' });
        }

        // 更新新密码
        await pool.execute(
            `UPDATE ${tableName} SET password_hash = ? WHERE ${idField} = ?`,
            [newPassword, idValue]
        );

        res.json({ message: '密码修改成功' });
    } catch (err) {
        console.error('修改密码错误:', err);
        res.status(500).json({ error: '修改密码失败: ' + err.message });
    }
});

module.exports = router;