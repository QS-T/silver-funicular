const jwt = require('jsonwebtoken');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key_2026';

// 生成 JWT（兼容管理员和教师）
function generateToken(user) {
    const payload = {
        role: user.role,
        username: user.username || user.name,
        // 同时保留两种 ID，只会有一种存在
        ...(user.admin_id && { admin_id: user.admin_id }),
        ...(user.teacher_id && { teacher_id: user.teacher_id }),
        ...(user.permissions && { permissions: user.permissions })
    };
    return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}

// 验证 JWT 中间件
function authenticate(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: '未提供认证令牌' });
    }

    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ error: '认证令牌已过期' });
        }
        return res.status(401).json({ error: '无效的认证令牌' });
    }
}

// 角色权限检查
function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: '未认证' });
        }
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: '权限不足，需要角色: ' + roles.join(' 或 ') });
        }
        next();
    };
}

module.exports = { generateToken, authenticate, requireRole };