// ==================== 教师端主逻辑 ====================
document.addEventListener('DOMContentLoaded', function() {
    const user = getUser();
    if (!user || !getToken()) {
        window.location.href = 'index.html';
        return;
    }
    if (user.role !== '教师') {
        alert('您不是教师账号，请使用正确的账号登录');
        window.location.href = 'index.html';
        return;
    }

    const TEACHER_ID = user.teacher_id;
    const TEACHER_NAME = user.name || TEACHER_ID;

    document.getElementById('userName').textContent = TEACHER_NAME;
    document.getElementById('userRole').textContent = '授课教师';

    // ==================== 日期格式化函数 ====================
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        const d = new Date(dateStr);
        if (isNaN(d.getTime())) return dateStr;
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // 页面状态
    let currentPage = 'dashboard';
    
    const renderers = {
        dashboard: renderDashboard,
        clock: renderClock,
        schedule: renderSchedule,
        attendance: renderAttendance,
        leave: renderLeave
    };
    
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            switchPage(page);
        });
    });
    
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('确定要退出登录吗？')) {
            clearToken();
            window.location.href = 'index.html';
        }
    });

    // 修改密码按钮
    document.getElementById('changePwdBtn').addEventListener('click', function(e) {
        e.preventDefault();
        showChangePasswordModal();
    });
    
    function switchPage(page) {
        currentPage = page;
        document.querySelectorAll('.nav-item[data-page]').forEach(el => {
            el.classList.toggle('active', el.dataset.page === page);
        });
        if (renderers[page]) {
            renderers[page]();
        }
    }

    // ==================== 修改密码模态框 ====================
    function showChangePasswordModal() {
        const existing = document.getElementById('changePwdOverlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'changePwdOverlay';
        overlay.style.cssText = `
            position: fixed; top:0; left:0; width:100%; height:100%;
            background: rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center;
            z-index: 9999;
        `;
        overlay.innerHTML = `
            <div style="background:#fff; border-radius:16px; padding:32px; width:400px; max-width:90%; box-shadow:0 20px 60px rgba(0,0,0,0.3);">
                <h2 style="text-align:center; color:#1a3a5c; margin-bottom:20px;">🔑 修改密码</h2>
                <div class="form-group">
                    <label>旧密码</label>
                    <input type="password" id="oldPwd" placeholder="请输入旧密码" style="width:100%; padding:10px; border:2px solid #e2e8f0; border-radius:8px;">
                </div>
                <div class="form-group">
                    <label>新密码</label>
                    <input type="password" id="newPwd" placeholder="请输入新密码（至少6位）" style="width:100%; padding:10px; border:2px solid #e2e8f0; border-radius:8px;">
                </div>
                <div class="form-group">
                    <label>确认新密码</label>
                    <input type="password" id="confirmPwd" placeholder="请再次输入新密码" style="width:100%; padding:10px; border:2px solid #e2e8f0; border-radius:8px;">
                </div>
                <div id="changePwdMsg" style="margin-top:10px; text-align:center; color:#e53e3e;"></div>
                <div style="display:flex; gap:12px; margin-top:20px; justify-content:center;">
                    <button class="btn btn-primary" id="changePwdSubmit">确认修改</button>
                    <button class="btn btn-outline" id="changePwdCancel">取消</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('#changePwdCancel').addEventListener('click', function() {
            overlay.remove();
        });
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) overlay.remove();
        });

        overlay.querySelector('#changePwdSubmit').addEventListener('click', async function() {
            const oldPwd = document.getElementById('oldPwd').value.trim();
            const newPwd = document.getElementById('newPwd').value.trim();
            const confirmPwd = document.getElementById('confirmPwd').value.trim();
            const msgEl = document.getElementById('changePwdMsg');

            if (!oldPwd || !newPwd || !confirmPwd) {
                msgEl.textContent = '❌ 请填写所有字段';
                return;
            }
            if (newPwd !== confirmPwd) {
                msgEl.textContent = '❌ 两次输入的新密码不一致';
                return;
            }
            if (newPwd.length < 6) {
                msgEl.textContent = '❌ 新密码长度至少6位';
                return;
            }

            this.disabled = true;
            this.textContent = '提交中...';
            msgEl.textContent = '';

            try {
                const token = getToken();
                const response = await fetch('/api/auth/change-password', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    },
                    body: JSON.stringify({ oldPassword: oldPwd, newPassword: newPwd })
                });
                const data = await response.json();
                if (!response.ok) {
                    throw new Error(data.error || '修改失败');
                }
                msgEl.style.color = '#38a169';
                msgEl.textContent = '✅ 密码修改成功！请重新登录。';
                setTimeout(() => {
                    clearToken();
                    window.location.href = 'index.html';
                }, 2000);
            } catch (err) {
                msgEl.style.color = '#e53e3e';
                msgEl.textContent = '❌ ' + err.message;
            } finally {
                this.disabled = false;
                this.textContent = '确认修改';
            }
        });
    }

    // ==================== 看板 ====================
    async function renderDashboard() {
        const container = document.getElementById('mainContent');
        container.innerHTML = `
            <div class="page-header">
                <h1>📊 我的看板</h1>
                <div class="subtitle">${new Date().toLocaleDateString('zh-CN')}</div>
            </div>
            <div class="stats-grid" id="statsGrid">
                <div class="stat-card"><div class="number blue" id="statTotal">-</div><div class="label">本月总课时</div></div>
                <div class="stat-card"><div class="number green" id="statNormal">-</div><div class="label">正常出勤</div></div>
                <div class="stat-card"><div class="number orange" id="statLate">-</div><div class="label">迟到</div></div>
                <div class="stat-card"><div class="number red" id="statAbsent">-</div><div class="label">旷工</div></div>
            </div>
            <div class="card">
                <div class="card-header"><h3>📋 本月考勤概览</h3></div>
                <div id="dashboardTable"><p style="color:#8a9bb0;">加载中...</p></div>
            </div>
        `;
        
        try {
            const now = new Date();
            const year = now.getFullYear();
            const month = now.getMonth() + 1;
            
            const summary = await API.reports.teacherSummary(TEACHER_ID, year, month);
            if (summary) {
                document.getElementById('statTotal').textContent = Number(summary.total_hours).toFixed(2) || 0;
                document.getElementById('statNormal').textContent = Number(summary.normal_days) || 0;
                document.getElementById('statLate').textContent = Number(summary.late_days) || 0;
                document.getElementById('statAbsent').textContent = Number(summary.absent_days) || 0;
            }
            
            const records = await API.attendance.getByTeacher(TEACHER_ID, {
                start_date: `${year}-${String(month).padStart(2,'0')}-01`,
                end_date: `${year}-${String(month).padStart(2,'0')}-${new Date(year, month, 0).getDate()}`
            });
            
            const tableHtml = records.length === 0 ? 
                '<p style="color:#8a9bb0;">本月暂无考勤记录</p>' :
                `<div class="table-responsive">
                    <table>
                        <thead><tr><th>日期</th><th>上班打卡</th><th>下班打卡</th><th>状态</th><th>实际课时</th></tr></thead>
                        <tbody>
                            ${records.map(r => `
                                <tr>
                                    <td>${formatDate(r.check_date)}</td>
                                    <td>${r.check_in || '-'}</td>
                                    <td>${r.check_out || '-'}</td>
                                    <td><span class="status-badge ${r.status}">${r.status}</span></td>
                                    <td>${Number(r.actual_hours).toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>`;
            document.getElementById('dashboardTable').innerHTML = tableHtml;
            
        } catch (err) {
            document.getElementById('dashboardTable').innerHTML = `<p style="color:#e53e3e;">加载失败: ${err.message}</p>`;
        }
    }
    
    // ==================== 打卡（实时打卡，无时间选择） ====================
    function renderClock() {
        const container = document.getElementById('mainContent');
        const today = new Date().toISOString().split('T')[0];
        container.innerHTML = `
            <div class="page-header">
                <h1>⏰ 打卡</h1>
                <div class="subtitle">${today}</div>
            </div>
            <div class="card">
                <div class="card-header"><h3>今日打卡</h3></div>
                <div style="display:flex; gap:16px; flex-wrap:wrap; align-items:center;">
                    <div class="form-group" style="flex:1;min-width:180px;">
                        <label>教师</label>
                        <input type="text" id="clockTeacher" value="${TEACHER_ID}" readonly style="background:#f7fafc;">
                    </div>
                    <div style="display:flex; gap:10px; align-self:flex-end; padding-bottom:4px; flex-wrap:wrap;">
                        <button class="btn btn-success" id="clockInBtn">⏰ 上班打卡</button>
                        <button class="btn btn-warning" id="clockOutBtn">⏰ 下班打卡</button>
                    </div>
                </div>
                <div id="clockResult" style="margin-top:12px; font-weight:500;"></div>
            </div>
            <div class="card">
                <div class="card-header"><h3>📋 今日考勤状态</h3></div>
                <div id="todayStatus"><p style="color:#8a9bb0;">加载中...</p></div>
            </div>
        `;

        loadTodayStatus();

        // 上班打卡
        document.getElementById('clockInBtn').addEventListener('click', async function() {
            const teacherId = document.getElementById('clockTeacher').value.trim();
            const checkDate = new Date().toISOString().split('T')[0];
            const now = new Date();
            const timeStr = now.toTimeString().slice(0, 8);

            if (!teacherId) {
                document.getElementById('clockResult').innerHTML = '<span style="color:#e53e3e;">❌ 教师信息错误</span>';
                return;
            }

            this.disabled = true;
            this.textContent = '提交中...';
            document.getElementById('clockResult').innerHTML = '';

            try {
                const result = await API.attendance.clock({
                    teacher_id: teacherId,
                    check_date: checkDate,
                    check_in: timeStr,
                    check_out: null
                });
                document.getElementById('clockResult').innerHTML = `<span style="color:#38a169;">✅ 上班打卡成功！状态: ${result.record.status}</span>`;
                loadTodayStatus();
            } catch (err) {
                document.getElementById('clockResult').innerHTML = `<span style="color:#e53e3e;">❌ ${err.message}</span>`;
            } finally {
                this.disabled = false;
                this.textContent = '⏰ 上班打卡';
            }
        });

        // 下班打卡
        document.getElementById('clockOutBtn').addEventListener('click', async function() {
            const teacherId = document.getElementById('clockTeacher').value.trim();
            const checkDate = new Date().toISOString().split('T')[0];
            const now = new Date();
            const timeStr = now.toTimeString().slice(0, 8);

            if (!teacherId) {
                document.getElementById('clockResult').innerHTML = '<span style="color:#e53e3e;">❌ 教师信息错误</span>';
                return;
            }

            this.disabled = true;
            this.textContent = '提交中...';
            document.getElementById('clockResult').innerHTML = '';

            try {
                const result = await API.attendance.clock({
                    teacher_id: teacherId,
                    check_date: checkDate,
                    check_in: null,
                    check_out: timeStr
                });
                document.getElementById('clockResult').innerHTML = `<span style="color:#38a169;">✅ 下班打卡成功！状态: ${result.record.status}</span>`;
                loadTodayStatus();
            } catch (err) {
                document.getElementById('clockResult').innerHTML = `<span style="color:#e53e3e;">❌ ${err.message}</span>`;
            } finally {
                this.disabled = false;
                this.textContent = '⏰ 下班打卡';
            }
        });
    }

    async function loadTodayStatus() {
        const today = new Date().toISOString().split('T')[0];
        try {
            const records = await API.attendance.getByTeacher(TEACHER_ID, {
                start_date: today,
                end_date: today
            });
            const container = document.getElementById('todayStatus');
            if (records.length === 0) {
                container.innerHTML = '<p style="color:#8a9bb0;">今日尚未打卡</p>';
            } else {
                const r = records[0];
                container.innerHTML = `
                    <div style="display:flex; gap:20px; flex-wrap:wrap;">
                        <div><strong>日期：</strong>${formatDate(r.check_date)}</div>
                        <div><strong>上班：</strong>${r.check_in || '-'}</div>
                        <div><strong>下班：</strong>${r.check_out || '-'}</div>
                        <div><strong>状态：</strong><span class="status-badge ${r.status}">${r.status}</span></div>
                        <div><strong>实际课时：</strong>${Number(r.actual_hours).toFixed(2)}</div>
                    </div>
                `;
            }
        } catch (err) {
            document.getElementById('todayStatus').innerHTML = `<p style="color:#e53e3e;">加载失败</p>`;
        }
    }

    // ==================== 排班 ====================
    async function renderSchedule() {
        const container = document.getElementById('mainContent');
        container.innerHTML = `
            <div class="page-header">
                <h1>📅 我的排班</h1>
                <div class="subtitle">当前学期课程安排</div>
            </div>
            <div class="card">
                <div class="card-header"><h3>📋 排班表</h3></div>
                <div id="scheduleTable"><p style="color:#8a9bb0;">加载中...</p></div>
            </div>
        `;
        
        try {
            const schedules = await API.schedules.getByTeacher(TEACHER_ID);
            const tableHtml = schedules.length === 0 ?
                '<p style="color:#8a9bb0;">暂无排班信息</p>' :
                `<div class="table-responsive">
                    <table>
                        <thead><tr><th>课程</th><th>上课时间</th><th>教室</th><th>周次</th><th>单节课时</th></tr></thead>
                        <tbody>
                            ${schedules.map(s => `
                                <tr>
                                    <td><strong>${s.course_name}</strong></td>
                                    <td>${s.class_time}</td>
                                    <td>${s.classroom}</td>
                                    <td>${s.weeks}</td>
                                    <td>${Number(s.hours_per_session).toFixed(1)} 课时</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>`;
            document.getElementById('scheduleTable').innerHTML = tableHtml;
        } catch (err) {
            document.getElementById('scheduleTable').innerHTML = `<p style="color:#e53e3e;">加载失败: ${err.message}</p>`;
        }
    }
    
    // ==================== 考勤记录 ====================
    async function renderAttendance() {
        const container = document.getElementById('mainContent');
        container.innerHTML = `
            <div class="page-header">
                <h1>📋 考勤记录</h1>
                <div class="actions">
                    <input type="month" id="filterMonth" value="${new Date().toISOString().slice(0,7)}">
                    <button class="btn btn-primary btn-sm" id="filterBtn">筛选</button>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3>📊 考勤明细</h3></div>
                <div id="attendanceTable"><p style="color:#8a9bb0;">加载中...</p></div>
            </div>
        `;
        
        await loadAttendanceRecords();
        document.getElementById('filterBtn').addEventListener('click', loadAttendanceRecords);
    }
    
    async function loadAttendanceRecords() {
        const monthVal = document.getElementById('filterMonth').value;
        if (!monthVal) return;
        const [year, month] = monthVal.split('-').map(Number);
        const startDate = `${year}-${String(month).padStart(2,'0')}-01`;
        const endDate = `${year}-${String(month).padStart(2,'0')}-${new Date(year, month, 0).getDate()}`;
        
        try {
            const records = await API.attendance.getByTeacher(TEACHER_ID, {
                start_date: startDate,
                end_date: endDate
            });
            const tableHtml = records.length === 0 ?
                '<p style="color:#8a9bb0;">该月暂无考勤记录</p>' :
                `<div class="table-responsive">
                    <table>
                        <thead><tr><th>日期</th><th>上班打卡</th><th>下班打卡</th><th>状态</th><th>实际课时</th><th>备注</th></tr></thead>
                        <tbody>
                            ${records.map(r => `
                                <tr>
                                    <td>${formatDate(r.check_date)}</td>
                                    <td>${r.check_in || '-'}</td>
                                    <td>${r.check_out || '-'}</td>
                                    <td><span class="status-badge ${r.status}">${r.status}</span></td>
                                    <td>${Number(r.actual_hours).toFixed(2)}</td>
                                    <td>${r.remark || '-'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>`;
            document.getElementById('attendanceTable').innerHTML = tableHtml;
        } catch (err) {
            document.getElementById('attendanceTable').innerHTML = `<p style="color:#e53e3e;">加载失败: ${err.message}</p>`;
        }
    }
    
    // ==================== 请假申请 ====================
    async function renderLeave() {
        const container = document.getElementById('mainContent');
        container.innerHTML = `
            <div class="page-header">
                <h1>📝 请假申请</h1>
                <button class="btn btn-primary" id="newLeaveBtn">➕ 提交申请</button>
            </div>
            <div class="card">
                <div class="card-header"><h3>📋 我的请假记录</h3></div>
                <div id="leaveTable"><p style="color:#8a9bb0;">加载中...</p></div>
            </div>
            <div id="leaveFormContainer" style="display:none;"></div>
        `;
        
        await loadLeaveRecords();
        document.getElementById('newLeaveBtn').addEventListener('click', function() {
            showLeaveForm();
        });
    }
    
    async function loadLeaveRecords() {
        try {
            const leaves = await API.leaves.getByTeacher(TEACHER_ID);
            const tableHtml = leaves.length === 0 ?
                '<p style="color:#8a9bb0;">暂无请假记录</p>' :
                `<div class="table-responsive">
                    <table>
                        <thead><tr><th>编号</th><th>类型</th><th>起止时间</th><th>事由</th><th>状态</th><th>审核人</th></tr></thead>
                        <tbody>
                            ${leaves.map(l => `
                                <tr>
                                    <td>${l.leave_id}</td>
                                    <td>${l.leave_type}</td>
                                    <td>${formatDate(l.start_date)} 至 ${formatDate(l.end_date)}</td>
                                    <td>${l.reason}</td>
                                    <td><span class="status-badge ${l.status === '已通过' ? 'approved' : l.status === '已驳回' ? 'rejected' : 'pending'}">${l.status}</span></td>
                                    <td>${l.approver || '-'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>`;
            document.getElementById('leaveTable').innerHTML = tableHtml;
        } catch (err) {
            document.getElementById('leaveTable').innerHTML = `<p style="color:#e53e3e;">加载失败: ${err.message}</p>`;
        }
    }
    
    function showLeaveForm() {
        const container = document.getElementById('leaveFormContainer');
        if (container.style.display === 'block') {
            container.style.display = 'none';
            return;
        }
        
        container.style.display = 'block';
        container.innerHTML = `
            <div class="card" style="border:2px solid #4a8db7;">
                <div class="card-header">
                    <h3>📝 提交请假申请</h3>
                    <button class="btn btn-outline btn-sm" id="closeLeaveForm">✕ 关闭</button>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>请假编号 *</label>
                        <input type="text" id="leaveId" placeholder="如 L004" value="L004">
                    </div>
                    <div class="form-group">
                        <label>教师 *</label>
                        <input type="text" id="leaveTeacher" value="${TEACHER_ID}" readonly style="background:#f7fafc;">
                    </div>
                    <div class="form-group">
                        <label>请假类型 *</label>
                        <select id="leaveType">
                            <option value="病假">病假</option>
                            <option value="事假" selected>事假</option>
                            <option value="调课">调课</option>
                            <option value="年假">年假</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>开始日期 *</label>
                        <input type="date" id="leaveStart" value="${new Date().toISOString().split('T')[0]}">
                    </div>
                    <div class="form-group">
                        <label>结束日期 *</label>
                        <input type="date" id="leaveEnd" value="${new Date().toISOString().split('T')[0]}">
                    </div>
                    <div class="form-group" style="grid-column:1/-1;">
                        <label>事由 *</label>
                        <textarea id="leaveReason" placeholder="请详细描述请假事由..." rows="2"></textarea>
                    </div>
                </div>
                <div style="display:flex; gap:12px; margin-top:12px;">
                    <button class="btn btn-primary" id="submitLeaveBtn">提交申请</button>
                    <button class="btn btn-outline" id="cancelLeaveBtn">取消</button>
                </div>
                <div id="leaveFormResult" style="margin-top:10px;"></div>
            </div>
        `;
        
        document.getElementById('closeLeaveForm').addEventListener('click', () => container.style.display = 'none');
        document.getElementById('cancelLeaveBtn').addEventListener('click', () => container.style.display = 'none');
        
        document.getElementById('submitLeaveBtn').addEventListener('click', async function() {
            const leaveId = document.getElementById('leaveId').value.trim();
            const teacherId = document.getElementById('leaveTeacher').value.trim();
            const leaveType = document.getElementById('leaveType').value;
            const startDate = document.getElementById('leaveStart').value;
            const endDate = document.getElementById('leaveEnd').value;
            const reason = document.getElementById('leaveReason').value.trim();
            const resultEl = document.getElementById('leaveFormResult');
            
            if (!leaveId || !teacherId || !startDate || !endDate || !reason) {
                resultEl.innerHTML = '<span style="color:#e53e3e;">❌ 请填写所有必填字段</span>';
                return;
            }
            
            this.disabled = true;
            this.textContent = '提交中...';
            resultEl.innerHTML = '';
            
            try {
                await API.leaves.create({
                    leave_id: leaveId,
                    teacher_id: teacherId,
                    leave_type: leaveType,
                    start_date: startDate,
                    end_date: endDate,
                    reason: reason
                });
                resultEl.innerHTML = '<span style="color:#38a169;">✅ 请假申请已提交，请等待审核</span>';
                container.style.display = 'none';
                await loadLeaveRecords();
            } catch (err) {
                resultEl.innerHTML = `<span style="color:#e53e3e;">❌ ${err.message}</span>`;
            } finally {
                this.disabled = false;
                this.textContent = '提交申请';
            }
        });
    }
    
    // 默认加载看板
    switchPage('dashboard');
});